package com.renadam.demo;

public class SerializationTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
	public static String serialize(Entity[] entities){
		return "";
		}
	
	//private static Entity[] deserialize(String myString){
	//	
	//}
}
